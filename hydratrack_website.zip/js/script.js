let cartCount = 0;
const cartCountElement = document.getElementById('cart-count');
document.querySelectorAll('.add-to-cart').forEach(button => {
  button.addEventListener('click', () => {
    cartCount++;
    cartCountElement.textContent = cartCount;
  });
});